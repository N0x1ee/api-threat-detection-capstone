"""Start the system:  python run.py   then open http://localhost:8000"""
import os
import threading
import webbrowser

from app.pipeline import Pipeline
from app.server import create_app
from app.training import load_or_train

PORT = int(os.environ.get("PORT", 8000))

if __name__ == "__main__":
    agents = load_or_train()
    pipeline = Pipeline(agents, os.path.join(os.path.dirname(os.path.abspath(__file__)), "audit.db"))
    app = create_app(pipeline)
    print(f"\n  API Threat Detection is running ->  http://localhost:{PORT}\n  Press Ctrl+C to stop.\n")
    threading.Timer(1.2, lambda: webbrowser.open(f"http://localhost:{PORT}")).start()
    app.run(host="0.0.0.0", port=PORT, threaded=True, debug=False)
