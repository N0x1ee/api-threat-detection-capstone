# Adaptive Multi-Agent & Explainable AI System for Real-Time API Threat Detection

MCA major project. Runs on one laptop. No Docker, no Kafka, no internet needed.

## Run it (2 minutes)

```
pip install -r requirements.txt
python run.py
```

Your browser opens at http://localhost:8000. The first run trains the three agents (a few seconds).
To reproduce the research numbers: `python evaluate.py` (about 40 seconds, writes `results/evaluation.md`).

## 5-minute demo script

1. Click **Mixed traffic (with zero-day)**. Watch the counters, charts and decision table fill up.
2. Click a **BLOCK** row. Show the plain-English reason, the suspicious parts of the payload, and each agent's score, confidence and weight.
3. In **Try one request**, pick *Normal search* (cleared by the fast filter in about 1 ms), then *SQL injection, obfuscated* (caught although never seen in training). *Normal, but contains an apostrophe* scores low but may land in FLAG. Be ready to explain that: the fast filter is cautious about apostrophes, and the agents decide.
4. Pick *Probe of a hidden admin page*. Only the **behavior** agent sees this one. This shows why confidence-weighted voting beats simple majority voting.
5. Use the **Review queue** to allow or block flagged requests. Those clicks feed the adaptive weights.
6. Optional: `curl "http://localhost:8000/gateway/search?q=%27+OR+1%3D1--"` returns HTTP 403 with the explanation.

## How the code maps to the proposal

| Proposal | This project |
|---|---|
| Fast filter, under 5 ms | `app/pipeline.py` FastFilter (rules + decision cache) |
| Agent 1: Isolation Forest | `app/agents.py` AnomalyAgent (same model) |
| Agent 2: character-level CNN | `app/agents.py` PayloadAgent (character n-gram model, see below) |
| Agent 3: LSTM | `app/agents.py` BehaviorAgent (Markov sequence model, see below) |
| Agents run in parallel | ThreadPoolExecutor, 3 workers |
| Confidence-weighted voting | `app/decision.py` combine() |
| Weights update automatically | `app/decision.py` WeightManager (every 100 labelled requests in the demo, 1,000 in the proposal) |
| Explainable AI | `app/decision.py` explain(): text built from real model evidence |
| Dashboard and audit log | `static/index.html`, SQLite file `audit.db` |

## Differences from the written proposal (say this before they ask)

- **Spring Boot, Kafka, Go, Redis, PostgreSQL, React and Docker are replaced** by one Python process with SQLite and an in-memory cache. Reason: it must run on any lab machine without setup. The pipeline stages are the same, and each is its own class, so each can be moved into its own service later.
- **The CNN and LSTM are replaced** by lighter models with the same job (read the payload, learn sequences). They train in seconds and need no GPU or TensorFlow. If your teachers require deep learning, swap those two classes in `app/agents.py`. They only need `analyze()` to return a score and a confidence.
- **The dashboard refreshes by polling every 1.2 seconds**, not by WebSocket.
- **Explanations are template text** filled with what the models actually found. A language model does not write them.
- **Adaptive weights need labels.** In the demo, labels come from the simulator and from analyst clicks. With real traffic you only have analyst clicks.

## Limits to be honest about

- All data is synthetic and made by the same generator that trained the agents. Known-attack scores are optimistic. The "novel" attacks (obfuscated variants held out of training) are the fairer test. To claim real accuracy, evaluate on a public dataset such as CSIC 2010.
- The win over simple majority voting is helped by the scanner case, where only one agent has evidence. That is a real weakness of majority voting, but it is one scenario, not proof of general superiority.
- Most attacks end as **FLAG** (score 0.3 to 0.7), not BLOCK. Averaging three agents pulls scores toward the middle. The thresholds are constants in `app/decision.py` if you want to tune them.
- Behavior history is kept in memory per user and resets when the server restarts.

## Files

```
run.py                start everything
evaluate.py           compares voting methods, writes results/evaluation.md
app/traffic.py        synthetic normal, attack and scanner traffic
app/agents.py         the three agents
app/decision.py       weighted voting, adaptive weights, explanations
app/pipeline.py       session store, fast filter, parallel agents, audit log
app/server.py         gateway, dashboard API, traffic simulator
static/index.html     dashboard
```
