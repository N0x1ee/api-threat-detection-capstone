"""Reproduces the research claims on fresh synthetic traffic (different seed from training).

Run:  python evaluate.py
Writes results/evaluation.md
"""
import random
import time

from app.decision import AGENT_NAMES, combine, verdict_for
from app.pipeline import Pipeline
from app.traffic import ATTACK_KINDS, generate_session
from app.training import load_or_train

EQUAL = {n: 1 / 3 for n in AGENT_NAMES}


def build_test_set(seed=99):
    rng = random.Random(seed)
    reqs, t = [], 0.0
    plan = [("normal", False)] * 500
    for k in ATTACK_KINDS:
        plan += [(k, False)] * 80 + [(k, True)] * 80
    plan += [("recon", False)] * 60
    rng.shuffle(plan)
    for kind, novel in plan:
        s = generate_session(rng, kind, t, novel)
        for r in s:
            r["novel"] = r.get("novel", False) and r["label"] == 1
        reqs += s
        t = s[-1]["ts"] + 1
    return reqs


def metrics(rows, predict):
    tp = fp = tn = fn = 0
    for r in rows:
        pred, y = predict(r), r["req"]["label"]
        tp += pred and y
        fp += pred and not y
        fn += (not pred) and y
        tn += (not pred) and (not y)
    prec = tp / (tp + fp) if tp + fp else 0
    rec = tp / (tp + fn) if tp + fn else 0
    f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0
    return dict(precision=prec, recall=rec, f1=f1, fpr=fp / (fp + tn) if fp + tn else 0,
                tp=tp, fp=fp, fn=fn, tn=tn)


def main():
    agents = load_or_train()
    pipe = Pipeline(agents, ":memory:")
    reqs = build_test_set()
    print(f"Test set: {len(reqs)} requests ({sum(r['label'] for r in reqs)} malicious). Running...")
    rows, t0 = [], time.time()
    for req in reqs:
        rec = pipe.process(req, force_ai=True, log=False)
        rows.append({"req": req, "rec": rec, "res": rec["results"]})
    print(f"Done in {time.time() - t0:.1f}s")

    sc = lambda r, n: r["res"][n].score
    methods = {
        "Anomaly agent alone": lambda r: sc(r, "anomaly") >= 0.5,
        "Payload agent alone": lambda r: sc(r, "payload") >= 0.5,
        "Behavior agent alone": lambda r: sc(r, "behavior") >= 0.5,
        "Simple majority vote (2 of 3)": lambda r: sum(sc(r, n) >= 0.5 for n in AGENT_NAMES) >= 2,
        "Equal-weight average": lambda r: sum(sc(r, n) for n in AGENT_NAMES) / 3 >= 0.5,
        "Confidence-weighted vote (ours)": lambda r: combine(r["res"], EQUAL) >= 0.5,
    }
    lines = ["# Evaluation results", "",
             f"Test set: {len(reqs)} requests, {sum(r['label'] for r in reqs)} malicious, "
             "fresh synthetic traffic (seed differs from training). A request counts as 'detected' "
             "when its final score is 0.5 or higher.", "",
             "## 1. Voting methods compared (all requests analysed by the agents)", "",
             "| Method | Precision | Recall | F1 | False-alarm rate |", "|---|---|---|---|---|"]
    for name, fn in methods.items():
        m = metrics(rows, fn)
        lines.append(f"| {name} | {m['precision']:.3f} | {m['recall']:.3f} | {m['f1']:.3f} | {m['fpr']:.3f} |")

    novel = [r for r in rows if r["req"].get("novel")]
    known = [r for r in rows if r["req"]["label"] == 1 and r["req"]["attack_type"] != "recon"
             and not r["req"].get("novel")]
    recon = [r for r in rows if r["req"]["attack_type"] == "recon"]
    lines += ["", "## 2. Detection rate by attack group", "",
              "| Method | Known attacks | Novel (zero-day style) | Scanner requests |", "|---|---|---|---|"]
    for name, fn in methods.items():
        rate = lambda grp: sum(bool(fn(r)) for r in grp) / len(grp)
        lines.append(f"| {name} | {rate(known):.3f} | {rate(novel):.3f} | {rate(recon):.3f} |")

    # End to end: fast filter first, then agents, three outcomes
    def e2e(r):
        return r["rec"]["verdict"] if r["rec"]["fast_suspicious"] else "ALLOW"
    normal = [r for r in rows if r["req"]["label"] == 0]
    attacks = [r for r in rows if r["req"]["label"] == 1]
    bypass = sum(not r["rec"]["fast_suspicious"] for r in normal) / len(normal)
    att_bypass = sum(not r["rec"]["fast_suspicious"] for r in attacks) / len(attacks)
    ver = lambda grp, v: sum(e2e(r) == v for r in grp) / len(grp)
    lat = sorted(r["rec"]["latency_ms"] for r in rows)
    lines += ["", "## 3. Full pipeline (fast filter + agents + thresholds 0.3 / 0.7)", "",
              "| | ALLOW | FLAG | BLOCK |", "|---|---|---|---|",
              f"| Normal requests | {ver(normal, 'ALLOW'):.3f} | {ver(normal, 'FLAG'):.3f} | {ver(normal, 'BLOCK'):.3f} |",
              f"| Malicious requests | {ver(attacks, 'ALLOW'):.3f} | {ver(attacks, 'FLAG'):.3f} | {ver(attacks, 'BLOCK'):.3f} |",
              "", f"- Normal traffic that skipped the AI agents (fast filter): **{bypass * 100:.1f}%** "
              "(the proposal assumed about 80%)",
              f"- Malicious requests wrongly passed by the fast filter: **{att_bypass * 100:.1f}%**",
              f"- Agent analysis time: median **{lat[len(lat) // 2]:.1f} ms**, 95th percentile "
              f"**{lat[int(len(lat) * .95)]:.1f} ms**, worst **{lat[-1]:.1f} ms** (target: under 200 ms)",
              "", "Caveat: this is synthetic data made by the same generator as the training data. "
              "Known-attack scores are optimistic. The novel-attack row is the more honest number. "
              "Re-run on a public dataset (for example CSIC 2010) before claiming real-world accuracy."]
    out = "\n".join(lines)
    print("\n" + out)
    with open("results/evaluation.md", "w") as f:
        f.write(out + "\n")


if __name__ == "__main__":
    main()
