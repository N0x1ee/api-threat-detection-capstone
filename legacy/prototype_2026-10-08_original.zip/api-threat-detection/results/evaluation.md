# Evaluation results

Test set: 5427 requests, 1600 malicious, fresh synthetic traffic (seed differs from training). A request counts as 'detected' when its final score is 0.5 or higher.

## 1. Voting methods compared (all requests analysed by the agents)

| Method | Precision | Recall | F1 | False-alarm rate |
|---|---|---|---|---|
| Anomaly agent alone | 0.842 | 0.269 | 0.408 | 0.021 |
| Payload agent alone | 1.000 | 0.373 | 0.543 | 0.000 |
| Behavior agent alone | 0.971 | 0.875 | 0.920 | 0.011 |
| Simple majority vote (2 of 3) | 1.000 | 0.351 | 0.519 | 0.000 |
| Equal-weight average | 1.000 | 0.362 | 0.531 | 0.000 |
| Confidence-weighted vote (ours) | 1.000 | 0.974 | 0.987 | 0.000 |

## 2. Detection rate by attack group

| Method | Known attacks | Novel (zero-day style) | Scanner requests |
|---|---|---|---|
| Anomaly agent alone | 0.666 | 0.681 | 0.000 |
| Payload agent alone | 1.000 | 0.866 | 0.000 |
| Behavior agent alone | 0.672 | 0.703 | 1.000 |
| Simple majority vote (2 of 3) | 0.887 | 0.866 | 0.000 |
| Equal-weight average | 0.931 | 0.878 | 0.000 |
| Confidence-weighted vote (ours) | 0.981 | 0.894 | 0.999 |

## 3. Full pipeline (fast filter + agents + thresholds 0.3 / 0.7)

| | ALLOW | FLAG | BLOCK |
|---|---|---|---|
| Normal requests | 0.999 | 0.001 | 0.000 |
| Malicious requests | 0.017 | 0.728 | 0.256 |

- Normal traffic that skipped the AI agents (fast filter): **98.7%** (the proposal assumed about 80%)
- Malicious requests wrongly passed by the fast filter: **1.2%**
- Agent analysis time: median **6.6 ms**, 95th percentile **10.8 ms**, worst **82.8 ms** (target: under 200 ms)

Caveat: this is synthetic data made by the same generator as the training data. Known-attack scores are optimistic. The novel-attack row is the more honest number. Re-run on a public dataset (for example CSIC 2010) before claiming real-world accuracy.
