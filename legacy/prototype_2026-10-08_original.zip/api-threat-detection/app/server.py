"""Web server: the real gateway (/gateway/...), the dashboard API (/api/...), and a traffic simulator."""
import os
import random
import threading
import time

from flask import Flask, jsonify, request

from .traffic import ATTACK_KINDS, generate_session, mixed_sessions, normalize_endpoint

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class Simulator:
    def __init__(self, pipeline):
        self.pipe, self.thread = pipeline, None
        self.state = {"running": False, "done": 0, "total": 0, "mode": ""}
        self.stop_flag = False

    def start(self, mode, sessions, novel, delay=0.03):
        if self.thread and self.thread.is_alive():
            return False
        rng, t0 = random.Random(), time.time()
        if mode == "mixed":
            reqs = mixed_sessions(rng, sessions, t0, novel_share=0.4 if novel else 0.0)
        else:
            reqs, t = [], t0
            for _ in range(sessions):
                s = generate_session(rng, mode, t, novel=novel)
                reqs += s
                t = s[-1]["ts"] + 1
        self.stop_flag = False
        self.state = {"running": True, "done": 0, "total": len(reqs), "mode": mode}
        self.thread = threading.Thread(target=self._run, args=(reqs, delay), daemon=True)
        self.thread.start()
        return True

    def _run(self, reqs, delay):
        for r in reqs:
            if self.stop_flag:
                break
            self.pipe.process(r, learn=True)
            self.state["done"] += 1
            time.sleep(delay)
        self.state["running"] = False


def create_app(pipeline):
    app = Flask(__name__, static_folder=os.path.join(ROOT, "static"), static_url_path="/static")
    sim = Simulator(pipeline)

    @app.get("/")
    def index():
        return app.send_static_file("index.html")

    # ----- the real gateway: send any request here and it is inspected before "forwarding"
    @app.route("/gateway/<path:p>", methods=["GET", "POST", "PUT", "DELETE", "PATCH"])
    def gateway(p):
        path = "/" + p
        body = request.get_data(as_text=True) or ""
        ip = request.headers.get("X-Forwarded-For", request.remote_addr or "0.0.0.0")
        req = {"method": request.method, "path": path, "endpoint": normalize_endpoint(path),
               "query": request.query_string.decode(errors="ignore"), "body": body[:5000],
               "headers": dict(request.headers), "ip": ip,
               "user": request.headers.get("X-User-Id") or ip, "ts": time.time(), "label": None}
        rec = pipeline.process(req)
        out = {"decision": rec["verdict"], "score": rec["score"], "explanation": rec["explanation"]["summary"]}
        if rec["verdict"] == "BLOCK":
            return jsonify(out), 403
        if rec["verdict"] == "FLAG":
            out["note"] = "Held for analyst review"
            return jsonify(out), 202
        out["note"] = "Forwarded to backend (demo: no real backend attached)"
        return jsonify(out), 200

    # ----- used by the dashboard's "try a request" box
    @app.post("/api/analyze")
    def analyze():
        d = request.get_json(force=True, silent=True) or {}
        path = d.get("endpoint") or "/search"
        ua = d.get("user_agent", "Mozilla/5.0 (Windows NT 10.0) Chrome/118.0")
        user = d.get("user") or "demo-user"
        req = {"method": d.get("method", "GET"), "path": path, "endpoint": normalize_endpoint(path),
               "query": d.get("query", ""), "body": d.get("body", ""),
               "headers": {"Host": "api.shop.example", "Accept": "application/json", "User-Agent": ua},
               "ip": "127.0.0.1", "user": user, "ts": time.time(), "label": None}
        return jsonify(pipeline.public(pipeline.process(req)))

    @app.get("/api/stats")
    def stats():
        s = pipeline.stats()
        s["simulator"] = sim.state
        return jsonify(s)

    @app.post("/api/simulate")
    def simulate():
        d = request.get_json(force=True, silent=True) or {}
        mode = d.get("mode", "mixed")
        if mode not in ["mixed", "normal", "recon"] + ATTACK_KINDS:
            return jsonify(error="unknown mode"), 400
        ok = sim.start(mode, int(min(max(d.get("sessions", 15), 1), 200)), bool(d.get("novel", False)))
        return jsonify(started=ok)

    @app.post("/api/simulate/stop")
    def stop():
        sim.stop_flag = True
        return jsonify(ok=True)

    @app.post("/api/override")
    def override():
        d = request.get_json(force=True, silent=True) or {}
        rec = pipeline.override(int(d.get("id", -1)), d.get("action", ""))
        return (jsonify(pipeline.public(rec)), 200) if rec else (jsonify(error="not found"), 404)

    @app.post("/api/reset")
    def reset():
        sim.stop_flag = True
        time.sleep(0.1)
        pipeline.reset_all()
        return jsonify(ok=True)

    return app
