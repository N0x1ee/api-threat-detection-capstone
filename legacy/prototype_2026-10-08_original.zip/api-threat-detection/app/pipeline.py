"""The full request pipeline: session -> fast filter -> 3 agents (parallel) -> vote -> explain -> log."""
import hashlib
import json
import re
import sqlite3
import threading
import time
from collections import OrderedDict, deque
from concurrent.futures import ThreadPoolExecutor

from .decision import AGENT_NAMES, WeightManager, combine, explain, verdict_for
from .traffic import KNOWN_ENDPOINTS, normalize_text

TOOL_RE = re.compile(r"sqlmap|nikto|nmap|masscan|python-requests|curl|wget|dirbuster|gobuster|scanner", re.I)
BAD_CHARS = set("'<>;|`$()\\")
BAD_WORDS = re.compile(r"\b(select|union|insert|drop|delete|update|exec|script|alert|onerror|onload|"
                       r"onfocus|eval|passwd|shadow|wget|curl|whoami|sleep|javascript|iframe)\b", re.I)
BAD_PATTERNS = re.compile(r"\.\./|\.\.\\|/etc/|%00|--|/\*|\bor\b\s*['\d]", re.I)
RATE_WINDOW = 10.0


class SessionStore:
    """Per-user history (stands in for the Redis session cache)."""

    def __init__(self, max_users=5000):
        self.data, self.max_users, self.lock = OrderedDict(), max_users, threading.Lock()

    def add(self, key, ts, endpoint):
        with self.lock:
            dq = self.data.pop(key, None) or deque(maxlen=60)
            dq.append((ts, endpoint))
            self.data[key] = dq
            if len(self.data) > self.max_users:
                self.data.popitem(last=False)
            rate = sum(1 for t, _ in dq if t >= ts - RATE_WINDOW)
            return [e for _, e in dq], rate


class FastFilter:
    """Cheap rule check. Anything that looks clean skips the AI agents."""

    def __init__(self):
        self.clean_cache = OrderedDict()   # stands in for the Redis decision cache

    def _payload_ok(self, req):
        key = hashlib.sha1(f"{req['method']}|{req['endpoint']}|{req.get('query')}|{req.get('body')}".encode()).hexdigest()
        if key in self.clean_cache:
            return self.clean_cache[key], True
        text = normalize_text((req.get("query") or "") + " " + (req.get("body") or ""))
        reasons = []
        if any(c in BAD_CHARS for c in text):
            reasons.append("contains special characters used in attacks")
        if BAD_WORDS.search(text):
            reasons.append("contains attack-related keywords")
        if BAD_PATTERNS.search(text):
            reasons.append("matches a known attack pattern")
        if len(text) > 400:
            reasons.append("payload is unusually long")
        if not reasons:
            self.clean_cache[key] = []
            if len(self.clean_cache) > 5000:
                self.clean_cache.popitem(last=False)
        return reasons, False

    def check(self, req, rate):
        reasons = []
        if req["endpoint"] not in KNOWN_ENDPOINTS:
            reasons.append(f"endpoint {req['endpoint']} is not one the API normally serves")
        ua = (req.get("headers") or {}).get("User-Agent", "")
        if not ua:
            reasons.append("no User-Agent header")
        elif TOOL_RE.search(ua):
            reasons.append("User-Agent looks like a hacking or scripting tool")
        if rate > 8:
            reasons.append(f"{rate} requests in 10 seconds")
        p_reasons, cached = self._payload_ok(req)
        reasons += p_reasons
        return bool(reasons), reasons, cached


class Pipeline:
    def __init__(self, agents, db_path, update_every=100):
        self.anomaly, self.payload, self.behavior = agents
        self.sessions, self.fast = SessionStore(), FastFilter()
        self.weights = WeightManager(update_every=update_every)
        self.pool = ThreadPoolExecutor(max_workers=3)
        self.lock = threading.Lock()
        self.db = sqlite3.connect(db_path, check_same_thread=False)
        self.db.execute("""CREATE TABLE IF NOT EXISTS decisions (
            id INTEGER PRIMARY KEY, ts REAL, ip TEXT, user TEXT, method TEXT, path TEXT, payload TEXT,
            route TEXT, score REAL, verdict TEXT, attack_type TEXT, explanation TEXT, agents TEXT,
            latency_ms REAL, label INTEGER, override TEXT)""")
        self.db.commit()
        row = self.db.execute("SELECT COALESCE(MAX(id),0) FROM decisions").fetchone()
        self.next_id = row[0] + 1
        self.reset_memory()

    def reset_memory(self):
        with self.lock:
            self.recent = OrderedDict()
            self.counters = {"total": 0, "fast": 0, "ai": 0, "ALLOW": 0, "FLAG": 0, "BLOCK": 0}
            self.latencies = deque(maxlen=120)
            self.ai_latencies = deque(maxlen=500)

    def reset_all(self):
        with self.lock:
            self.db.execute("DELETE FROM decisions")
            self.db.commit()
        self.reset_memory()
        self.weights.reset()
        self.sessions = SessionStore()

    # ---------------------------------------------------------------- core
    def run_agents(self, req, history, rate):
        f = {
            "anomaly": self.pool.submit(self.anomaly.analyze, req),
            "payload": self.pool.submit(self.payload.analyze, req),
            "behavior": self.pool.submit(self.behavior.analyze, history, rate),
        }
        return {n: fut.result() for n, fut in f.items()}

    def process(self, req, force_ai=False, log=True, learn=False):
        t0 = time.perf_counter()
        history, rate = self.sessions.add(req.get("user") or req.get("ip"), req["ts"], req["endpoint"])
        suspicious, fast_reasons, cached = self.fast.check(req, rate)
        weights = dict(self.weights.weights)
        rec = {"ts": req["ts"], "ip": req.get("ip", ""), "user": req.get("user", ""),
               "method": req["method"], "path": req["path"],
               "payload": ((req.get("query") or "") + " " + (req.get("body") or "")).strip()[:300],
               "label": req.get("label"), "fast_suspicious": suspicious,
               "fast_reasons": fast_reasons, "override": None}
        if not suspicious and not force_ai:
            rec.update(route="fast", score=0.0, verdict="ALLOW", agents={}, weights=weights,
                       explanation={"summary": "Allowed by the fast filter in a few milliseconds. No AI needed.",
                                    "evidence": ["Known endpoint, clean payload, normal request rate."]
                                    + (["Decision came from the cache."] if cached else []),
                                    "action": "No action needed.", "attack_type": "normal", "lead_agent": None})
            results = None
        else:
            results = self.run_agents(req, history, rate)
            final = combine(results, weights)
            verdict = verdict_for(final)
            expl = explain(results, weights, final, verdict, fast_reasons)
            rec.update(route="ai", score=round(final, 4), verdict=verdict, explanation=expl, weights=weights,
                       agents={n: {"score": round(r.score, 3), "confidence": round(r.confidence, 3),
                                   "weight": round(weights[n], 3), "reason": r.detail.get("reason", "")}
                               for n, r in results.items()})
        rec["latency_ms"] = round((time.perf_counter() - t0) * 1000, 2)
        rec["results"] = results            # kept for the evaluator; stripped before sending to the UI
        rec["attack_type"] = rec["explanation"]["attack_type"]
        if not log:
            return rec
        with self.lock:
            rec["id"] = self.next_id
            self.next_id += 1
            c = self.counters
            c["total"] += 1
            c["fast" if rec["route"] == "fast" else "ai"] += 1
            c[rec["verdict"]] += 1
            self.latencies.append((rec["route"], rec["latency_ms"]))
            if rec["route"] == "ai":
                self.ai_latencies.append(rec["latency_ms"])
            self.recent[rec["id"]] = rec
            while len(self.recent) > 1500:
                self.recent.popitem(last=False)
        rec["results"] = None
        if learn and rec["label"] is not None and rec["route"] == "ai":
            self.weights.feedback({n: a["score"] for n, a in rec["agents"].items()}, rec["label"])
        self._save(rec)
        return rec

    def _save(self, r):
        with self.lock:
            self.db.execute("INSERT INTO decisions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                            (r["id"], r["ts"], r["ip"], r["user"], r["method"], r["path"], r["payload"], r["route"],
                             r["score"], r["verdict"], r["attack_type"], json.dumps(r["explanation"]),
                             json.dumps(r["agents"]), r["latency_ms"], r["label"], r["override"]))
            self.db.commit()

    # ---------------------------------------------------------------- analyst
    def override(self, rec_id, action):
        with self.lock:
            rec = self.recent.get(rec_id)
            if not rec or action not in ("allow", "block"):
                return None
            rec["override"] = action
            self.db.execute("UPDATE decisions SET override=? WHERE id=?", (action, rec_id))
            self.db.commit()
        if rec["agents"]:
            self.weights.feedback({n: a["score"] for n, a in rec["agents"].items()},
                                  1 if action == "block" else 0)
        return rec

    # ---------------------------------------------------------------- stats
    @staticmethod
    def public(rec):
        keys = ["id", "ts", "ip", "user", "method", "path", "payload", "route", "score", "verdict",
                "attack_type", "explanation", "agents", "latency_ms", "label", "override", "fast_reasons"]
        return {k: rec.get(k) for k in keys}

    def stats(self):
        with self.lock:
            recs = list(self.recent.values())
            c = dict(self.counters)
            lat = list(self.latencies)
            ai = sorted(self.ai_latencies)
        types = {}
        for r in recs:
            if r["verdict"] != "ALLOW":
                types[r["attack_type"]] = types.get(r["attack_type"], 0) + 1
        fast_lat = [l for k, l in lat if k == "fast"]
        queue = [self.public(r) for r in reversed(recs) if r["verdict"] == "FLAG" and not r["override"]][:12]
        try:
            self.db.execute("SELECT 1").fetchone()
            db_ok = True
        except Exception:
            db_ok = False
        return {
            "counters": c,
            "fast_share": round(c["fast"] / c["total"] * 100, 1) if c["total"] else 0,
            "avg_fast_ms": round(sum(fast_lat) / len(fast_lat), 2) if fast_lat else 0,
            "avg_ai_ms": round(sum(ai) / len(ai), 1) if ai else 0,
            "p95_ai_ms": round(ai[int(len(ai) * 0.95) - 1], 1) if len(ai) >= 20 else (ai[-1] if ai else 0),
            "latency_series": [round(l, 2) for _, l in lat[-80:]],
            "attack_types": types,
            "agents": self.weights.snapshot(),
            "queue": queue,
            "recent": [self.public(r) for r in reversed(recs)][:30],
            "health": {"gateway": True, "fast_filter": True, "anomaly": True, "payload": True,
                       "behavior": True, "decision_engine": True, "xai": True, "database": db_ok},
        }
