"""Confidence-weighted voting, adaptive agent weights, and plain-English explanations."""
import threading
from collections import deque

AGENT_NAMES = ["anomaly", "payload", "behavior"]
AGENT_TITLES = {"anomaly": "Anomaly agent", "payload": "Payload agent", "behavior": "Behavior agent"}
ALLOW_BELOW, BLOCK_ABOVE = 0.3, 0.7


def combine(results, weights):
    """final = sum(weight * confidence * score) / sum(weight * confidence)"""
    num = den = 0.0
    for name, r in results.items():
        w = weights[name] * r.confidence
        num += w * r.score
        den += w
    return num / den if den > 0 else 0.0


def verdict_for(score):
    if score < ALLOW_BELOW:
        return "ALLOW"
    return "FLAG" if score <= BLOCK_ABOVE else "BLOCK"


class WeightManager:
    """Agents that were right recently get more say. Updated every `update_every` labelled requests
    (the proposal says 1,000; the demo default is lower so you can see it move)."""

    def __init__(self, update_every=200, window=500):
        self.update_every, self.window = update_every, window
        self.lock = threading.Lock()
        self.reset()

    def reset(self):
        with self.lock:
            self.weights = {n: 1 / 3 for n in AGENT_NAMES}
            self.recent = {n: deque(maxlen=self.window) for n in AGENT_NAMES}
            self.seen = 0
            self.updates = 0
            self.history = [dict(self.weights)]

    def feedback(self, scores, label):
        """scores: {agent: score}; label: 1 = real attack, 0 = normal (from analyst or simulator)."""
        with self.lock:
            for n in AGENT_NAMES:
                self.recent[n].append(int((scores[n] >= 0.5) == bool(label)))
            self.seen += 1
            if self.seen % self.update_every == 0:
                acc = {n: sum(d) / len(d) for n, d in self.recent.items() if d}
                raw = {n: acc.get(n, 0.5) ** 4 for n in AGENT_NAMES}
                tot = sum(raw.values())
                self.weights = {n: raw[n] / tot for n in AGENT_NAMES}
                self.updates += 1
                self.history.append(dict(self.weights))

    def snapshot(self):
        with self.lock:
            acc = {n: (sum(d) / len(d) if d else None) for n, d in self.recent.items()}
            return {"weights": dict(self.weights), "accuracy": acc, "labelled": self.seen,
                    "updates": self.updates, "update_every": self.update_every,
                    "history": list(self.history[-30:])}


# ------------------------------------------------------------------ explanations
ATTACK_LABEL = {
    "sqli": "SQL injection attempt", "xss": "Cross-site scripting (XSS) attempt",
    "cmdi": "OS command injection attempt", "traversal": "Path traversal attempt",
    "recon": "Automated scanning / reconnaissance", "anomaly": "Unusual request structure",
    "suspicious": "Suspicious request", "normal": "Normal traffic",
}


def classify(results, final):
    p, b, a = results["payload"], results["behavior"], results["anomaly"]
    if p.score >= 0.5:
        return p.detail.get("attack_type", "suspicious")
    if b.score >= 0.5:
        return "recon"
    if a.score >= 0.5:
        return "anomaly"
    return "suspicious" if final >= ALLOW_BELOW else "normal"


def explain(results, weights, final, verdict, fast_reasons):
    atype = classify(results, final)
    contrib = {n: weights[n] * r.confidence * r.score for n, r in results.items()}
    lead = max(contrib, key=contrib.get)
    evidence = []
    for n in ("payload", "anomaly", "behavior"):
        r = results[n]
        if r.score >= 0.3 and r.detail.get("reason"):
            evidence.append(f"{AGENT_TITLES[n]}: {r.detail['reason']}")
    quiet = [AGENT_TITLES[n] for n, r in results.items() if r.score < 0.3]
    if quiet:
        evidence.append(f"Saw nothing unusual: {', '.join(quiet)}.")
    if fast_reasons:
        evidence.append("Fast filter sent this to the AI agents because: " + "; ".join(fast_reasons) + ".")
    label = ATTACK_LABEL[atype]
    if verdict == "BLOCK":
        summary = f"Blocked: {label}. Threat score {final:.2f}. Strongest alarm came from the {AGENT_TITLES[lead].lower()}."
        action = "Block this request. Review the user and IP for repeated attempts."
    elif verdict == "FLAG":
        summary = f"Flagged for review: {label.lower()}. Threat score {final:.2f}. The agents were not fully sure."
        action = "Hold for an analyst. Use the review queue to allow or block it."
    else:
        summary = f"Allowed. Threat score {final:.2f}. The AI agents checked this request and found it normal."
        action = "No action needed."
    return {"summary": summary, "evidence": evidence, "action": action,
            "attack_type": atype, "lead_agent": lead}
